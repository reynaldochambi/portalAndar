import { Routes } from '@angular/router';
import { Login } from './modules/auth/pages/login/login';
import { ProductList } from './modules/catalog/pages/product-list/product-list';
import { CartSumary } from './modules/cart/pages/cart-sumary/cart-sumary';

export const routes: Routes = [
//    { path: 'auth/login', component: Login },
  { path: 'catalog', component: ProductList },
  { path: 'cart', component: CartSumary },
  { path: '', redirectTo: 'catalog', pathMatch: 'full' }
];

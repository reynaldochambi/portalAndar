import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Producto } from '../../../../core/models/product/model';
import { Cart } from '../../../../core/services/cart';

@Component({
  selector: 'app-product-list',
  standalone: true, // Asegúrate de tener esto si usas imports directos
  imports: [CommonModule],
  templateUrl: './product-list.html',
  styleUrl: './product-list.css',
})
export class ProductList implements OnInit {
  
  // 1. Definición de la lista de productos
productos: Producto[] = [
  { 
    nombre: 'Oxford Clásico', 
    precio: 350, 
    categoria: 'Vestir', 
    material: 'Cuero natural de primera calidad', 
    detalles: 'Forro y plantilla Cuero camélido y antitranspirante',
    tallas: '38 al 43', 
    imagenes: ['assets/oxford-clasico.png'] 
  },
  { 
    nombre: 'Oxford Elegante', 
    precio: 370, 
    categoria: 'Vestir', 
    material: 'Cuero natural de primera calidad', 
    detalles: 'Forro y plantilla Cuero camélido y antitranspirante',
    tallas: '38 al 43', 
    imagenes: ['assets/oxford-elegante.png'] 
  },
  { 
    nombre: 'Oxford Media Luna', 
    precio: 330, 
    categoria: 'Vestir', 
    material: 'Cuero natural de primera calidad', 
    detalles: 'Forro y plantilla Cuero camélido y antitranspirante',
    tallas: '37 al 42', 
    imagenes: ['assets/oxford-medialuna.png'] 
  },
  { 
    nombre: 'Bota Altama', 
    precio: 350, 
    categoria: 'Militar', 
    material: 'Cuero natural de primera calidad', 
    detalles: 'Suela de alta resistencia, forro camélido',
    tallas: '37 al 42', 
    imagenes: ['assets/bota-altama.png'] 
  },
  { 
    nombre: 'Botín Chelsea', 
    precio: 380, 
    categoria: 'Casual', 
    material: 'Cuero viejo graso de primera calidad', 
    detalles: 'Elásticos laterales, forro camélido',
    tallas: '37 al 42', 
    imagenes: ['assets/botin-chelsea.png'] 
  },
  { 
    nombre: 'Mocasín Clásico', 
    precio: 330, 
    categoria: 'Casual', 
    material: 'Cuero natural de primera calidad', 
    detalles: 'Sin cordones, forro camélido antitranspirante',
    tallas: '37 al 42', 
    imagenes: ['assets/mocasin-clasico.png'] 
  },
  { 
    nombre: 'Mocasín Sport', 
    precio: 330, 
    categoria: 'Casual', 
    material: 'Cuero natural de primera calidad', 
    detalles: 'Suela flexible, forro camélido',
    tallas: '37 al 42', 
    imagenes: ['assets/mocasin-sport.png'] 
  },
  { 
    nombre: 'Botín Caña Alta', 
    precio: 380, 
    categoria: 'Militar', 
    material: 'Cuero natural de primera calidad', 
    detalles: 'Protección de tobillo, forro camélido',
    tallas: '38 al 42', 
    imagenes: ['assets/botin-caña-alta.png'] 
  },
  { 
    nombre: 'Zapatenis', 
    precio: 350, 
    categoria: 'Casual', 
    material: 'Cuero natural de primera calidad', 
    detalles: 'Estilo zapatilla urbana, forro camélido',
    tallas: '38 al 42', 
    imagenes: ['assets/zapatenis.png'] 
  },
  { 
    nombre: 'Botín Caña baja', 
    precio: 350, 
    categoria: 'Casual', 
    material: 'Cuero natural de primera calidad', 
    detalles: 'Protección de tobillo, forro camélido antitranspirante',
    tallas: '38 al 42', 
    imagenes: ['assets/botin-caña-baja.png'] 
  }
];
  // 2. Variables de control para el Popup y filtrado
  zapatoSeleccionado: any = null;
  productosFiltrados: Producto[] = [];

  // 3. Funciones del componente
  ngOnInit() {
    this.productosFiltrados = this.productos; // Mostrar todos al inicio
  }

  abrirDetalle(producto: any) {
    this.zapatoSeleccionado = producto;
  }

  cerrarDetalle() {
    this.zapatoSeleccionado = null;
  }

  filtrar(categoria: string) {
    this.productosFiltrados = this.productos.filter(p => p.categoria === categoria);
  }

// En product-list.ts
constructor(private cartService: Cart) {} // Inyectar el servicio

  confirmarCompra() {
    //alert(`¡Excelente elección! El modelo ${this.zapatoSeleccionado.nombre} se añadirá a tu pedido.`);
if (this.zapatoSeleccionado) {
    this.cartService.agregarAlCarrito(this.zapatoSeleccionado);
    this.cerrarDetalle(); // Cerramos el popup
  }
  }
}
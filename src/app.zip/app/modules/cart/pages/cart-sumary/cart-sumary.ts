import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Cart } from '../../../../core/services/cart';


@Component({
  selector: 'app-cart-sumary',
  imports: [CommonModule],
  templateUrl: './cart-sumary.html',
  styleUrl: './cart-sumary.css',
})
export class CartSumary implements OnInit {
  articulos: any[] = [];
  total: number = 0;

  constructor(private cartService: Cart) {}

  ngOnInit() {
    this.cargarCarrito();
  }

  cargarCarrito() {
    this.articulos = this.cartService.obtenerArticulos();
    this.calcularTotal();
  }

  calcularTotal() {
    this.total = this.articulos.reduce((acc, item) => acc + item.precio, 0);
  }

  eliminar(index: number) {
    // Implementaremos una función en el servicio para esto luego
    this.articulos.splice(index, 1);
    this.calcularTotal();
    // Actualizar el contador del navbar también (opcional por ahora)
  }

  finalizarPedido() {
    const telf = "59176506362"; // <-- Pon aquí el número de WhatsApp de Andar Bolivia
  
  // Creamos el texto del mensaje
  let mensaje = "Hola Andar Bolivia! Quisiera realizar el siguiente pedido:%0A";
  
  this.articulos.forEach(item => {
    mensaje += `- ${item.nombre} (Bs ${item.precio})%0A`;
  });
  
  mensaje += `%0A*Total: Bs ${this.total}*`;
  
  // Abrimos el enlace de WhatsApp
  const url = `https://wa.me/${telf}?text=${mensaje}`;
  window.open(url, '_blank');
  }
}
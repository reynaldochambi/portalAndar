export interface Producto {
  nombre: string;
  precio: number;
  categoria:string;
  material: string;
  detalles: string;
  tallas: string;
  imagenes: string[];
}
/* export interface Producto {
  nombre: string;
  precio: number;
  categoria: 'Militar' | 'Casual' | 'Vestir' | 'Zapatilla';
  material: string;
  tallas: string;
  imagen: string;
  descripcion?: string;
}*/
import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { Cart } from '../../../core/services/cart';

@Component({
  selector: 'app-navbar',
  imports: [
    CommonModule, 
    RouterModule // 2. Lo agregamos aquí para que el HTML reconozca queryParams
  ],
  templateUrl: './navbar.html',
  styleUrl: './navbar.css',
})
export class Navbar {

 cantidadCarrito: number = 0;

  constructor(private cartService: Cart) {}

  ngOnInit() {
    // Nos quedamos escuchando si el número cambia
this.cartService.cartCount$.subscribe(count => {
      this.cantidadCarrito = count;
    });
  }
}
